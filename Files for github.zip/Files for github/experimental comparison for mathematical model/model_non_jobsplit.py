import sys 
sys.path.append("..") 
sys.path.append("E:/pyfiles/Commoncodes")
import matplotlib.pyplot as plt
import copy
import random
import pandas as pd
import numpy as np
# random.seed(1)
Operations_data=np.array(pd.read_excel('data.xlsx',sheet_name='Operations')).tolist()
Machine_tools_data=np.array(pd.read_excel('data.xlsx',sheet_name='Machine tools')).tolist()
Cutting_tools_data=np.array(pd.read_excel('data.xlsx',sheet_name='Cutting tools')).tolist()
variable1encode=[0.2201, 0.9325, 0.1033, 0.4179, 0.1931, 0.8117, 0.7364, 0.7737, 0.6219, 0.3439, 0.1537, 0.7993, 0.0464, 0.6386, 0.709, 0.9952, 0.0034, 0.7297, 0.4363, 0.3748, 0.9685, 0.1674, 0.52, 0.0501, 0.0365, 0.0416, 0.887, 0.015, 0.6245, 0.3548, 0.6915, 0.0475, 0.8644, 0.3632, 0.7174, 0.8123, 0.9058, 0.3818, 0.5663, 0.3782, 0.3584, 0.753, 0.4747, 0.0352, 0.6818, 0.9116, 0.1638, 0.3045, 0.4856, 0.198, 0.545, 0.8205, 0.6915, 0.8318, 0.311, 0.497, 0.4655, 0.9626, 0.8181, 0.8278, 0.6444, 0.965, 0.0565, 0.7868, 0.3977, 0.6623, 0.6788, 0.2834, 0.6014, 0.8991, 0.6139, 0.1416, 0.7191, 0.833, 0.1768, 0.2682, 0.8535, 0.6443, 0.607, 0.8023]
variable2encode=[0.0484, 0.7689, 0.0712, 0.5054, 0.9718, 0.9472, 0.6448, 0.2791, 0.2762, 0.8228, 0.3718, 0.0201, 0.3268, 0.8841, 0.8983, 0.3803, 0.6626, 0.8417, 0.5633, 0.9466, 0.5788, 0.7522, 0.4411, 0.8978, 0.9976, 0.0093, 0.6286, 0.8396, 0.2117, 0.8498, 0.9197, 0.3366, 0.6981, 0.0919, 0.7882, 0.5975, 0.9338, 0.9083, 0.3274, 0.8269, 0.6773, 0.7945, 0.5845, 0.6789, 0.567, 0.0025, 0.8822, 0.8849, 0.5425, 0.7506, 0.9828, 0.0458, 0.3761, 0.2903, 0.9023, 0.9575, 0.2961, 0.15, 0.9028, 0.4182, 0.0531, 0.1154, 0.1363, 0.0273, 0.7421, 0.0238, 0.4607, 0.4088, 0.4401, 0.1793, 0.3024, 0.5643, 0.4756, 0.1138, 0.2743, 0.2615, 0.4181, 0.864, 0.2754, 0.4471, 0.4824, 0.7449, 0.5275, 0.8134, 0.7762, 0.187, 0.0387, 0.5111, 0.6333, 0.5625, 0.6896, 0.308, 0.4233, 0.1781, 0.4152, 0.8357, 0.3425, 0.9922, 0.7072, 0.0341, 0.3692, 0.0292, 0.6509, 0.2399, 0.0578, 0.2625, 0.7301, 0.8295, 0.699, 0.8924, 0.3614, 0.8463, 0.7386, 0.3656, 0.8583, 0.0502, 0.647, 0.9434, 0.5263, 0.6984, 0.0963, 0.4892, 0.2059, 0.3475, 0.0777, 0.5019, 0.1158, 0.1252, 0.5084, 0.488, 0.2592, 0.6818, 0.9255, 0.4134, 0.2136, 0.0138, 0.9186, 0.0621, 0.9676, 0.3565, 0.9343, 0.755, 0.281, 0.8337, 0.0613, 0.6192, 0.3283, 0.5684, 0.1622, 0.3371, 0.9394, 0.7093, 0.9689, 0.318, 0.8066, 0.171, 0.639, 0.485, 0.8259, 0.8188, 0.0281, 0.533, 0.6591, 0.4609, 0.0296, 0.2571, 0.329, 0.5369, 0.9229, 0.2214, 0.5555, 0.7032, 0.349, 0.4366, 0.1579, 0.6213, 0.8972, 0.5633, 0.8754, 0.7938, 0.8724, 0.3844, 0.107, 0.0661, 0.1387, 0.2179, 0.278, 0.2728, 0.8818, 0.3489, 0.4391, 0.5443, 0.9833, 0.8288, 0.4182, 0.6031, 0.5551, 0.5575, 0.1866, 0.4771, 0.3853, 0.9895, 0.8008, 0.2217, 0.9502, 0.903, 0.1708, 0.5254, 0.0641, 0.6661, 0.1199, 0.6229, 0.2413, 0.2048, 0.5585, 0.1879, 0.9624, 0.6193, 0.1255, 0.9351, 0.9015, 0.3665, 0.9272, 0.1339, 0.437, 0.5978, 0.4842, 0.9247, 0.8753, 0.1872, 0.75, 0.4541, 0.1765, 0.0749, 0.4845, 0.0202, 0.0238, 0.1502, 0.6775, 0.1885, 0.0655, 0.3078, 0.3926, 0.9614, 0.6897, 0.2654, 0.1893, 0.7387, 0.2742, 0.3955, 0.2604, 0.1684, 0.7128, 0.6197, 0.8895, 0.4817, 0.9014, 0.4151, 0.7815, 0.5152, 0.164, 0.3401, 0.52, 0.0649, 0.0446, 0.0172, 0.4842, 0.9774, 0.5246, 0.737, 0.641, 0.5132, 0.6529, 0.1031, 0.1051, 0.5199, 0.9854, 0.7468, 0.1824, 0.4097, 0.3525, 0.8895, 0.7682, 0.5829, 0.4244, 0.3001, 0.8873, 0.3405, 0.5035, 0.3263, 0.4036, 0.5905, 0.1333, 0.46, 0.1464, 0.7338, 0.1482, 0.941, 0.5552, 0.3726, 0.6397, 0.5026, 0.0672, 0.5361, 0.306, 0.5189, 0.9486, 0.4961, 0.4027, 0.5477, 0.1653, 0.8916, 0.9486, 0.9764, 0.1508, 0.4015, 0.3607, 0.0333, 0.3993, 0.6582, 0.1185, 0.4391, 0.903, 0.1161, 0.123, 0.0352, 0.0162, 0.4764, 0.5884, 0.8081, 0.7681, 0.2526, 0.1653, 0.8215, 0.5375, 0.1263, 0.8343, 0.2838, 0.2942, 0.245, 0.2318, 0.5239, 0.5007, 0.1751, 0.8427, 0.9861, 0.4808, 0.2069, 0.3387, 0.2321, 0.8937, 0.052, 0.5178, 0.9059, 0.3365, 0.2918, 0.4897, 0.7088, 0.8806, 0.2586, 0.0795, 0.4051, 0.4138, 0.1055, 0.7318, 0.7047, 0.8999, 0.4099, 0.8869, 0.7199, 0.8815, 0.7427, 0.0178, 0.6483, 0.5548, 0.281, 0.4226, 0.7959, 0.0399, 0.6826, 0.9348, 0.0309, 0.1021, 0.5815, 0.9503, 0.2265, 0.9724, 0.205, 0.2269, 0.4245, 0.4536, 0.6517, 0.9241, 0.6571, 0.282, 0.1462, 0.3826, 0.7962, 0.0122, 0.2909, 0.8662, 0.5197, 0.8206, 0.7181, 0.3698, 0.3905, 0.5127, 0.8111, 0.7845, 0.3687, 0.6754, 0.552, 0.9181, 0.4509, 0.3595, 0.0789, 0.1172, 0.8383, 0.604, 0.2612, 0.8382, 0.3339, 0.5108, 0.4894, 0.4908, 0.9049, 0.6088, 0.2706, 0.7614, 0.9741, 0.1392, 0.2019, 0.993, 0.842, 0.9359, 0.618, 0.2888, 0.2552, 0.4105, 0.6991, 0.3565, 0.933, 0.0854, 0.811, 0.6448, 0.5701, 0.6291, 0.8438, 0.27, 0.8916, 0.0666, 0.8588, 0.1481, 0.418, 0.1655, 0.4383, 0.1371, 0.2279, 0.1343, 0.7291, 0.3948, 0.6264, 0.7092, 0.6508, 0.2699, 0.5332, 0.7178, 0.2069, 0.7994, 0.3473, 0.1952, 0.7065, 0.9841, 0.8749, 0.6688, 0.1934, 0.4841, 0.4549, 0.4066, 0.6207, 0.9164, 0.0065, 0.311, 0.8656, 0.7188, 0.9487, 0.0344, 0.0504, 0.9922, 0.3968, 0.4266, 0.3385, 0.2832, 0.4665, 0.2431, 0.8885, 0.3284, 0.4476, 0.5097, 0.9596, 0.411, 0.7313, 0.2752, 0.8935, 0.5848, 0.8041, 0.688, 0.1995, 0.3423, 0.9347, 0.6279, 0.3355, 0.4653, 0.1771, 0.0395, 0.1934, 0.9327, 0.0216, 0.8933, 0.4856, 0.2237, 0.1231, 0.8198, 0.6123, 0.9381, 0.5099, 0.7162, 0.8241, 0.5846, 0.8657, 0.5303, 0.0013, 0.2029, 0.7246, 0.7365, 0.5737, 0.4993, 0.8835, 0.6543, 0.556, 0.9362, 0.8065, 0.1852, 0.6185, 0.6265, 0.334, 0.9124, 0.0063, 0.4548, 0.98, 0.8371, 0.3258, 0.7562, 0.9844, 0.8469, 0.67, 0.5002, 0.279, 0.7362, 0.8699, 0.3233, 0.5888, 0.8621, 0.0057, 0.6376, 0.9492, 0.6977, 0.6639, 0.5505, 0.9575, 0.1109, 0.8072, 0.4057, 0.4765, 0.034, 0.6668, 0.2557, 0.6509, 0.4427, 0.2918, 0.1202, 0.9919, 0.0165, 0.5725, 0.4334, 0.6736, 0.8916, 0.4975, 0.2491, 0.757, 0.4249, 0.7938, 0.2779, 0.7653, 0.8361, 0.0743, 0.4437, 0.836, 0.1615, 0.9676, 0.6923, 0.1142, 0.5819, 0.1097, 0.7249, 0.0323, 0.2689, 0.8309, 0.2648, 0.1524, 0.6585, 0.4518, 0.9912, 0.4987, 0.3422, 0.8652, 0.3403, 0.3886, 0.5471, 0.4408, 0.1123, 0.1226, 0.8572, 0.6032, 0.7666, 0.838, 0.9136, 0.0814, 0.2761, 0.4864, 0.9113, 0.4419, 0.583, 0.9988, 0.3802, 0.6431, 0.9192, 0.6548, 0.2823, 0.7923, 0.4252, 1.0, 0.54, 0.3642, 0.4239, 0.9993, 0.4001, 0.05, 0.6596, 0.5186, 0.7074, 0.407, 0.4408, 0.3111, 0.1188, 0.2713, 0.9488, 0.7267, 0.9526, 0.2427, 0.9932, 0.4292, 0.7526, 0.8627, 0.2662, 0.2271, 0.2262, 0.722, 0.5916, 0.5075, 0.6565, 0.394, 0.1897, 0.3378, 0.5005, 0.1117, 0.1743, 0.3729, 0.6504, 0.5265, 0.8066, 0.1637, 0.3059, 0.0736, 0.0906, 0.9789, 0.0381, 0.3548, 0.0568, 0.8101, 0.8659, 0.7246, 0.561, 0.4498, 0.1934, 0.2829, 0.156, 0.3638, 0.6548, 0.3821, 0.811, 0.7369, 0.6191, 0.2762, 0.3796, 0.3862, 0.4647, 0.7578, 0.8962, 0.9501, 0.6383, 0.3471, 0.74, 0.4225, 0.5408, 0.8131, 0.9725, 0.1817, 0.3503, 0.1291, 0.0757, 0.0252, 0.0085, 0.787, 0.5235, 0.6277, 0.9506, 0.4705, 0.3209, 0.6552, 0.2622, 0.2494, 0.0499, 0.0248, 0.6345, 0.2378, 0.8889, 0.0935, 0.9252, 0.6217, 0.4164, 0.2129, 0.1302, 0.7583, 0.497, 0.0236, 0.0581, 0.8797, 0.0996, 0.86, 0.2112, 0.0701, 0.4482, 0.1924, 0.7086, 0.1491, 0.3114, 0.0452, 0.8186, 0.2135, 0.4575, 0.3144, 0.7332, 0.6384, 0.5403, 0.439, 0.4257, 0.3982, 0.4021, 0.0986, 0.9632, 0.9674, 0.2871, 0.5728, 0.702, 0.9918, 0.9179, 0.8555, 0.0996, 0.5787, 0.896, 0.676, 0.8816, 0.3266, 0.8788, 0.6948, 0.1148, 0.4376, 0.1184, 0.4121, 0.2909, 0.1582, 0.2474, 0.0961, 0.3331, 0.7014, 0.0735, 0.0865, 0.1494, 0.8402, 0.7686, 0.821, 0.6066, 0.1626, 0.5123, 0.0657, 0.2074, 0.8707, 0.0543, 0.7263, 0.21, 0.6474, 0.7308, 0.0403, 0.8593, 0.4423, 0.148, 0.4096, 0.5331, 0.1405, 0.4945, 0.056, 0.6295, 0.0952, 0.4276, 0.5131, 0.213, 0.4264, 0.6228, 0.1919, 0.4976, 0.1541, 0.696, 0.402, 0.8236, 0.9128, 0.3365, 0.5408, 0.5548, 0.8344, 0.6407, 0.957, 0.7883, 0.1715, 0.2125, 0.735, 0.8581, 0.9152, 0.9525, 0.852, 0.8775, 0.0495, 0.4773, 0.2572, 0.3276, 0.6067, 0.6377, 0.8537, 0.5312, 0.1595, 0.6709, 0.5658, 0.207, 0.9419, 0.1062, 0.0713, 0.4923, 0.8743, 0.5138, 0.6841, 0.4887, 0.5223, 0.5777, 0.4467, 0.5329, 0.8521, 0.8209, 0.0141, 0.862, 0.1996, 0.2437, 0.5195, 0.5334, 0.5366, 0.9389, 0.1127, 0.7402, 0.4581, 0.7859, 0.744, 0.5966, 0.6234, 0.128, 0.9485, 0.0919, 0.2204, 0.0798, 0.858, 0.8063, 0.943, 0.4127, 0.402, 0.94, 0.5548, 0.5924, 0.6064, 0.6595, 0.5036, 0.7611, 0.9801, 0.5577, 0.8718, 0.8315, 0.2749, 0.0476, 0.243, 0.4098, 0.3623, 0.922, 0.2185, 0.1847, 0.3024, 0.6735, 0.082, 0.1625, 0.894, 0.4353, 0.1752, 0.3347, 0.4287, 0.1094, 0.9358, 0.8624, 0.1286, 0.1192, 0.3561, 0.284, 0.838, 0.7079, 0.0357, 0.9672, 0.6031, 0.7973, 0.4648, 0.3603, 0.3283, 0.9798, 0.8087, 0.3853, 0.697, 0.7408, 0.6015, 0.892, 0.3093, 0.7899, 0.1191, 0.4203, 0.6673, 0.3299, 0.0135, 0.8716, 0.6237, 0.8426, 0.798, 0.1251, 0.6614, 0.8356, 0.9474, 0.9578, 0.6972, 0.0657, 0.5764, 0.7511, 0.0104, 0.3109, 0.4904, 0.009, 0.886, 0.1966, 0.4958, 0.8396, 0.517, 0.8896, 0.9371, 0.9033, 0.4628, 0.8611, 0.674, 0.888, 0.8484, 0.6689, 0.9875, 0.952, 0.5042, 0.7414, 0.4946, 0.2145, 0.8295, 0.7277, 0.9605, 0.2299, 0.9011, 0.267, 0.414, 0.0157, 0.6949, 0.9271, 0.0593, 0.6035]
def quchong(fitnesspop):#返回元素
    optimal_f2=[]
    for i in fitnesspop:
      if not i in optimal_f2:
        optimal_f2.append(i)
    return optimal_f2


#案例数据
n_machining_shop=max([Machine_tools_data[i][0] for i in range(len(Machine_tools_data))]) #分布式机械加工车间的数量
n_machine_tool=[0 for i in range(n_machining_shop)] #各分布式机械加工车间的机床数量
for i in range(len(Machine_tools_data)):
    n_machine_tool[Machine_tools_data[i][0]-1]=max(n_machine_tool[Machine_tools_data[i][0]-1],Machine_tools_data[i][1])

       


c0=[[Machine_tools_data[sum(n_machine_tool[:i])+j][5]  
     for j in range(n_machine_tool[i])] 
    for i in range(len(n_machine_tool))]

c1=[[Machine_tools_data[sum(n_machine_tool[:i])+j][6] 
     for j in range(n_machine_tool[i])] 
    for i in range(len(n_machine_tool))]

 
#附加载荷损耗功率的系数c0和c1
n_job=max([Operations_data[i][0] for i in range(len(Operations_data))]) #工件种类




n_tool=len(Cutting_tools_data)#刀具数量

n_job_operation_number=[0 
                        for i in range(n_job)] #各工件的工序数量
for i in range(len(Operations_data)):
    n_job_operation_number[Operations_data[i][0]-1]=max(n_job_operation_number[Operations_data[i][0]-1],Operations_data[i][3])

n_job_number=[Operations_data[sum(n_job_operation_number[:i])][2]
              for i in range(n_job)] #各工件所需的数量
n_batches_min=[Operations_data[sum(n_job_operation_number[:i])][14] 
               for i in range(n_job)]
n_batches_max=[Operations_data[sum(n_job_operation_number[:i])][15] 
               for i in range(n_job)]

n_job_feasible_shops=[[j for j in range(n_machining_shop)] for i in range(n_job)]#各个工件可选的车间
# n_job_operation_feasible_machines=[[[random.sample(list(range(n_machine_tool[k])),random.randint(2, n_machine_tool[k]))
#                                      for k in range(n_machining_shop)] 
#                                     for j in range(n_job_operation_number[i])] 
#                                    for i in range(n_job)]
#各工件的工序可选机床,四个索引分别对应工件、工序、车间、机床
n_job_operation_feasible_machines=[[[[]
                                     for k in range(n_machining_shop)] 
                                    for j in range(n_job_operation_number[i])] 
                                   for i in range(n_job)]

for i in range(n_job):#工件
    for j in range(n_job_operation_number[i]):#工序
        for k in range(n_machining_shop):#车间
            string0=Operations_data[sum(n_job_operation_number[:i])+j][6]
            b=string0.split(",")
            intlist=[[int( b[l][1])-1 ,int( b[l][2:])-1] for l in range(len(b))]
            n_job_operation_feasible_machines[i][j][k]=[intlist[l][1] for l in range(len(intlist)) if k==intlist[l][0] ]

n_job_operation_feasible_tools=[[[]
        for k in range(len(n_job_operation_feasible_machines[i]))]
    for i in range(len(n_job_operation_feasible_machines))]

for i in range(len(n_job_operation_feasible_tools)):
    for k in range(len(n_job_operation_feasible_tools[i])):
         string0=Operations_data[sum(n_job_operation_number[:i])+k][7]
         b=string0.split(",") 
         intlist=[int( b[l][1:])-1 for l in range(len(b))]
         n_job_operation_feasible_tools[i][k]=[intlist[l] for l in range(len(intlist))]

n_job_operation_feasible_machines_tools=[[[[]
                                           for j in range(len(n_machine_tool))] 
                                          for k in range(n_job_operation_number[i])]
                                         for i in range(n_job)]
#各工件的工序在各机床上的可选刀具,五个索引分别对应工件、工序、车间、机床、刀具
def data_set(input0):
    t_ts=[[[[[0
          for m in range(len(n_job_operation_feasible_machines_tools[i][j][k][l]))]
          for l in range(len(n_job_operation_feasible_machines_tools[i][j][k]))]
        for k in range(len(n_job_operation_feasible_machines_tools[i][j]))] 
        for j in range(len(n_job_operation_feasible_machines_tools[i]))] 
      for i in range(len(n_job_operation_feasible_machines_tools))]
    for i in range(len(n_job_operation_feasible_machines)):
        for j in range(len(n_job_operation_feasible_machines[i])):
            index0=sum(n_job_operation_number[:i])+j
            toolstring=Operations_data[index0][7]
            if ',' not in toolstring:
                t_tslist=(Operations_data[index0][input0]).replace("],[", "")
                toollist=(Operations_data[index0][7].replace("T", "")).split(',')
                toollist=[int(k)-1 for k in toollist]
                # machinelist0=((Operations_data[index0][6].strip('[]').replace("M", ""))).split(',')
                # machinelist=[[int(machinelist0[k][0])-1,int(machinelist0[k][1:])-1] for k in range(len(machinelist0))]
                t_tsstring=(t_tslist.strip('[]')).split(',')
                for k in range(len(t_ts[i][j])):
                    for l in range(len(t_ts[i][j][k])):
                        t_ts[i][j][k][l][0]=int(t_tsstring[0])
                        del(t_tsstring[0])
            else:
                toollist=(Operations_data[index0][7].replace("T", "")).split(',')
                toollist=[int(k)-1 for k in toollist]
                # machinelist0=((Operations_data[index0][6].strip('[]').replace("M", ""))).split(',')
                # machinelist=[[int(machinelist0[k][0])-1,int(machinelist0[k][1:])-1] for k in range(len(machinelist0))]
                t_tslist=(Operations_data[index0][input0])
                t_tsstringlen=len(t_tslist)
                t_tsstring=t_tslist[1:t_tsstringlen-1].split('],[')
                t_tsstring[0]=t_tsstring[0][1:]
                t_tsstring[-1]=t_tsstring[-1][:-1]
                for k in range(len(t_tsstring)):
                    t_tsstring[k]=t_tsstring[k].split(',')
                    t_tsstring[k]=[int(t_tsstring[k][l]) for l in range(len(t_tsstring[k]))]
                for k in range(len(t_ts[i][j])):
                    for l in range(len(t_ts[i][j][k])):
                            t_ts[i][j][k][l]=t_tsstring[0]
                            del(t_tsstring[0])
    return t_ts

for i in range(n_job):
    for k in range(n_job_operation_number[i]):
        index0=sum(n_job_operation_number[:i])+k
        machines=(Operations_data[index0][6].replace("M", "")).split(',')
        tool0=(Operations_data[index0][7].replace("T", "")).split(',')
        tool0=[int(tool0[l])-1 for l in range(len(tool0))]
        machine0=[[] for l in range(n_machining_shop)]
        for l in range(len(machines)):
            machine0[int(machines[l][0])-1].append(int(machines[l][1])-1)
        for j in range(len(machine0)):#每个车间
            n_job_operation_feasible_machines_tools[i][k][j]=[tool0  for l in range(len(machine0[j]))]
                                         

#下面这些需要处理
t_lu=[[[[0
          for l in range(len(n_job_operation_feasible_machines[i][j][k]))] 
        for k in range(len(n_job_operation_feasible_machines[i][j]))] 
        for j in range(len(n_job_operation_feasible_machines[i]))] 
      for i in range(len(n_job_operation_feasible_machines))]
for i in range(len(n_job_operation_feasible_machines)):
    for j in range(len(n_job_operation_feasible_machines[i])):
        t_lulist=(Operations_data[sum(n_job_operation_number[:i])+j][12].strip('[]')).split(',')
        for k in range(len(n_job_operation_feasible_machines[i][j])):
            for l in range(len(n_job_operation_feasible_machines[i][j][k])):
                t_lu[i][j][k][l]=int(t_lulist[0])
                del (t_lulist[0])
#各工件工序在各机床上的安装卸载时间之和,t_lu[i][j][k][m]是工件i的工序j在车间k的机床m的安装和拆卸时间之和
t_ts=data_set(13)#各工件工序在各机床上各刀具的对刀时间,t_ts[i][j][k][l][m]是工件i的工序j在车间k的机床l的采用刀具m的对刀时间
t_co=data_set(10)#各工件工序在各机床上采用各刀具的切削时间,t_co[i][j][k][l][m]是工件i的工序j在车间k的机床l的采用刀具m的切削时间
t_tc=data_set(11)#各工件工序在各机床上采用各刀具的换刀时间,t_tc[i][j][k][l][m]是工件i的工序j在车间k的机床l的采用刀具m的切削时间
P_mr=data_set(8)#各车间机床的物料去除功率,[i][j][k][l][m]分别对应工件、工序、车间、机床、刀具
P_ac=data_set(9)#各车间机床的空载功率,[i][j][k]分别对应车间、机床、刀具的编号*********这个有问题

P_st=[[0
        for j in range(n_machine_tool[i])]
      for i in range(len(n_machine_tool))]
for i in range(len(Machine_tools_data)):
        P_st[Machine_tools_data[i][0]-1][Machine_tools_data[i][1]-1]=Machine_tools_data[i][3]



P_ax=[[0 
        for j in range(n_machine_tool[i])]
      for i in range(len(n_machine_tool))]
for i in range(len(Machine_tools_data)):
        P_ax[Machine_tools_data[i][0]-1][Machine_tools_data[i][1]-1]=Machine_tools_data[i][4]
#各车间机床的待机功率、辅助设备功率,[i][j]分别对应车间号和机床号



T_tl=[Cutting_tools_data[i][4]*60 for i in range(len(Cutting_tools_data))]
# #各个刀具的寿命，索引分别是工件、工序、车间、机床、刀具





P_al=[[[[[c0[k][l]*P_mr[i][j][k][l][m]+
          P_mr[i][j][k][l][m]*P_mr[i][j][k][l][m]*c1[k][l]
          for m in range(len(n_job_operation_feasible_machines_tools[i][j][k][l]))] 
          for l in range(len(n_job_operation_feasible_machines_tools[i][j][k]))] 
        for k in range(len(n_job_operation_feasible_machines_tools[i][j]))] 
        for j in range(len(n_job_operation_feasible_machines_tools[i]))]
      for i in range(len(n_job_operation_feasible_machines_tools))]
#各车间机床的附加载荷损耗功率,[i][j][k][l][m]分别对应工件、工序、车间、机床、刀具


# #案例数据，需要根据事情情况修改****************************

n_variables_1=sum(n_batches_max)
n_variables_2=sum([n_batches_max[i]*n_job_operation_number[i] for i in range(n_job)])
n_variables=n_variables_1*3+n_variables_2*3

#变量数量，分别是:
#    订单分批的批次数量
#    订单各批次的工件数量
#    批次分配车间的情况
#    各批次工序选择机床的情况
#    各批次工序选择刀具的情况
#    各批次工序加工顺序的情况
def totalsum(input0):#能耗求和，最大阶级是3
    return0=0
    for i in range(len(input0)):
        for j in range(len(input0[i])):
            for k in range(len(input0[i][j])):
                    return0=return0+input0[i][j][k]
    return return0

def totalsum2(input0):#能耗求和，最大阶级是3
    return0=0
    for i in range(len(input0)):
        for j in range(len(input0[i])):
                    return0=return0+input0[i][j]
    return return0

def getBrightColor():
    # 获得亮色，保证其中两色分别90和ff，第三色为任意值即可
    full_range = ["0","1","2","3","4","5","6","7","8","9","a","b","c","d","e","f"]
    combination = ["90"]
    # 将 ff 随机插入 90 前或后
    combination.insert(random.randint(0,1),"ff")
    third_color = "{0}{1}".format(full_range[random.randint(0,15)],full_range[random.randint(0,15)])
    combination.insert(random.randint(0,2),third_color)
    color = "#" + "".join(combination)
    return color

def totalmax(input0):#时间的最大值，最大阶级是3
    return0=0
    for i in range(len(input0)):
        for j in range(len(input0[i])):
            for k in range(len(input0[i][j])):
                if return0<input0[i][j][k]:
                    return0=input0[i][j][k]
    return return0
    
def Operationtime(gongjian,piliang,gongxu,chejian,jichuang,daoju):
    t_lu0=t_lu[gongjian][gongxu][chejian][jichuang]*piliang
    t_ts0=(t_ts[gongjian][gongxu][chejian][jichuang][daoju])*piliang*(t_co[gongjian][gongxu][chejian][jichuang][daoju])/(T_tl[daoju])
    t_co0=t_co[gongjian][gongxu][chejian][jichuang][daoju]*piliang
    t_tc0=t_tc[gongjian][gongxu][chejian][jichuang][daoju]*piliang*t_co[gongjian][gongxu][chejian][jichuang][daoju]/T_tl[daoju]
    return t_lu0+t_ts0+t_co0+t_tc0
    

def endingtime(startingtime, job,operation, batch,jobshop,machinetool,tool):
    return startingtime+batch*t_lu[job][operation][jobshop][machinetool]+t_ts[job][operation][jobshop][machinetool][tool]*batch*t_co[job][operation][jobshop][machinetool][tool]/T_tl[tool]+t_co[tool]*batch+t_tc[job][operation][jobshop][machinetool][tool]*batch*t_co[job][operation][jobshop][machinetool][tool]/T_tl[tool]

def vector12vector2(vector1,distri):#一维向量转二维向量，输入分别是一维向量和分布情况
    assit=0
    return0=[0 for i in range(len(distri))]
    for i in range(len(distri)):
        return0[i]=vector1[assit:assit+distri[i]]
        assit+=distri[i]
    return return0

def vector12vector3(vector1,distri):#一维向量转二维向量，输入分别是一维向量和分布情况
    assit=0
    return0=[[0 for j in range(len(distri[i]))] for i in range(len(distri))]
    for i in range(len(distri)):
        for j in range(len(distri[i])):
            return0[i][j]=vector1[assit:
                                  assit+len(distri[i][j])]
        assit+=len(distri[i][j])
    return return0 


def fitnesspopfun(pop):
    return [fitness(i)[0:2] for i in pop]

def gantteplot(schedule,num):
    fig, axs = plt.subplots(n_machining_shop)

    picis=[0 for j in range(n_job)]#每个工件分了多少批次
    color_asit=[[]for i in range(n_job)]#颜色辅助变量
    color=[[]for i in range(n_machining_shop)]#颜色区分
    MS=[[]for i in range(n_machining_shop)]#机器编号
    T = [[]for i in range(n_machining_shop)]#操作持续时间
    macStartTime = [[]for i in range(n_machining_shop)]#操作开始时间
    J = [[]for i in range(n_machining_shop)]#工件号
    B=[[]for i in range(n_machining_shop)]#批次号
    oper = [[]for i in range(n_machining_shop)]#工序号
    for i in range(len(schedule)):#访问各个车间
        for j in schedule[i]:#访问各个机床
            for k in j:#访问各个操作
                MS[i].append(k[8])#机器号
                T[i].append(k[4])#操作持续时间
                macStartTime[i].append(k[3])#操作开始时间
                J[i].append(k[0]+1)#工件号
                B[i].append(k[1]+1)#批次号
                oper[i].append(k[2]+1)#工序号
                picis[k[0]]=max(picis[k[0]],k[1]+1)
    for i in range(len(picis)):#访问各个工件
        color_asit[i]=[getBrightColor() for k in range(picis[i])]
        # 画图
        
    for i in range(len(schedule)):#访问各个车间
        for j in schedule[i]:#访问各个机床
            for k in j:#访问各个操作
                color[i].append(color_asit[k[0]][k[1]])
    for i in range(len(schedule)):#访问各个车间
        gantt(axs[i],MS[i], T[i], macStartTime[i], J[i], B[i],oper[i],color[i])
        ax=axs[i]
        ax.set_yticks(range(n_machine_tool[i])) 
    plt.rcParams.update({'font.size': 4})
    plt.tight_layout()
    plt.savefig("allcmp"+str(num)+".svg",bbox_inches='tight') 
    plt.show()


def gantt(axs0,MS, T, macStartTime, workpiece,B, operation,colors):
    maxtime=max([T[i]+macStartTime[i] for i in range(len(T))])
    for i in range(len(MS)):
        axs0.barh(MS[i],T[i],0.5,left=macStartTime[i],color=colors[i])
        axs0.text(macStartTime[i] + T[i] / 2-maxtime*0.01, MS[i]-0.10, '%s-%s' %
                  (workpiece[i],B[i]), size=4)
        # figure0.xticks(fontsize=6) 
    # yticks_assit=['$M_{'+str(i+1)+'}$' for i in range(len(quchong(MS)))]
    # figure0.yticks(range(len(set(MS))), yticks_assit)

def fitness(individual0):#评价个体，给出对应的目标函数
    individual=copy.deepcopy(individual0)# individual0.tolist()#这个可能不需要
    variables1_encode=variable1encode   
    variables2_encode=variable2encode    
    variables3_encode=individual[2*n_variables_1:3*n_variables_1]    
    variables4_encode=individual[3*n_variables_1:3*n_variables_1+n_variables_2]    
    variables5_encode=individual[3*n_variables_1+n_variables_2:3*n_variables_1+2*n_variables_2]    
    variables6_encode=individual[3*n_variables_1+2*n_variables_2:]
    variables1_assit1=[0 if variables1_encode[i]<0.5 else 1 for i in range(len(variables1_encode))]
    variables1_assit2=vector12vector2(variables1_assit1,n_batches_max)
    variables1=[max(sum(variables1_assit2[i]),n_batches_min[i])  for i in range(len(variables1_assit2))]
    #第一个变量nj_i，各工件的批次数量

    variables2_assit1=vector12vector2(variables2_encode,n_batches_max)
    variables2=[[0 for j in range(variables1[i])] for i in range(len(variables1))]
    #第二个变量nb_ij，各批次里的工件数量
    for i in range(len(variables1)):
        assit0=variables2_assit1[i][0:variables1[i]]#第i个工件各批次的随机键
        for j in range(variables1[i]):
            if j< (variables1[i]-1):
                variables2[i][j]=max((int)(n_job_number[i]*assit0[j]/sum(assit0)),1) 
            else:
                variables2[i][j]=n_job_number[i]-sum(variables2[i])
    variables3_assit1=vector12vector2(variables3_encode,n_batches_max)
    variables3=[[0 for j in range(variables1[i])] for i in range(len(variables1))]
    #第三个变量nb_ij，各工序所选车间，索引分别包括工件，批次
    for i in range(len(variables1)):
        for j in range(variables1[i]):
            variables3[i][j]=(int)(variables3_assit1[i][j]*len(n_job_feasible_shops[i]))
            if variables3[i][j]==len(n_job_feasible_shops[i]):
                    variables3[i][j]-=1
    distrib1=[[[0
                for k in range(n_job_operation_number[i])]
                for j in range(variables1[i])]
              for i in range(n_job)]
    variables4_assit1=vector12vector3(variables4_encode,distrib1)
    variables4=copy.deepcopy(variables4_assit1)
    #第四个变量，各工序选择机床的情况，三个索引分别代表工件、批次、工序所对应的可选机床索引
    for i in range(len(variables4_assit1)):#工件
        for j in range(len(variables4_assit1[i])):#批次
            for k in range(len(variables4_assit1[i][j])):#工序
                variables4[i][j][k]=(int)(variables4_assit1[i][j][k]*len(n_job_operation_feasible_machines[i][k][variables3[i][j]]))
                if variables4[i][j][k]==len(n_job_operation_feasible_machines[i][k][variables3[i][j]]):
                    variables4[i][j][k]-=1
                #上面的是实际机床编号
    distrib2=[[[0
                for k in range(n_job_operation_number[i])] 
                for j in range(variables1[i])]
              for i in range(n_job)]
    variables5_assit1=vector12vector3(variables5_encode,distrib2)
    variables5=copy.deepcopy(variables4_assit1)
    #第五个变量，各工序选择刀具的情况，三个索引分别代表工件、批次、工序,所对应的可选刀具索引

    for i in range(len(variables4_assit1)):#工件
        for j in range(len(variables4_assit1[i])):#批次
            for k in range(len(variables4_assit1[i][j])):#工序
                variables5[i][j][k]=(int)(variables5_assit1[i][j][k]*len(n_job_operation_feasible_machines_tools[i][k][variables3[i][j]][variables4[i][j][k]]))
                if variables5[i][j][k]==len(n_job_operation_feasible_machines_tools[i][k][variables3[i][j]][variables4[i][j][k]]):
                    variables5[i][j][k]-=1
    distrib3=[[[0 
                for k in range(n_job_operation_number[i])] 
                for j in range(variables1[i])]
              for i in range(n_job)]
    variables6_assit1=vector12vector3(variables6_encode,distrib3)    
    # variables6=copy.deepcopy(variables4_assit1)#第五个变量，各工序选择刀具的情况，三个索引分别代表工件、批次、工序所对应的可选刀具索引
    operations_assit=[[]
                      for i in range(n_machining_shop)]#各个车间待调度的工序
    sequence_encode=[[]
                      for i in range(n_machining_shop)]#各个车间待调度工序顺序的编码
    
    for i in range(len(variables1)):
        for j in range(variables1[i]):
            for k in range(n_job_operation_number[i]):
                operations_assit[variables3[i][j]].append([i,j,k])
                sequence_encode[variables3[i][j]].append(variables6_assit1[i][j][k])
    sequence_assit=[[j
                      for j in range(len(sequence_encode[i]))]
                    for i in range(n_machining_shop)]#各个车间待调度工序顺序的编码
    operations=[[]
                for i in range(n_machining_shop)]
    for i in range(n_machining_shop):
        sequence_assit[i].sort(key = lambda x: sequence_encode[i][x])
        operations[i]=[operations_assit[i][sequence_assit[i][j]] 
                        for j in range(len(sequence_assit[i]))]

    # operations2=[[0 for j in range(variables1[i])] for i in range(n_job)]#各车间待调度的工序
    variables6=copy.deepcopy(operations)
    #第六个变量：各车间待调度工序的加工顺序，第一个索引是车间，第二个索引是第几个待调度的工序，第三个索引的0 1 2分别是工件、批次、工序
    for i in range(len(variables6)):
        batches=[]
        for j in variables6[i]:
            batches.append([j[0],j[1],0])
        batches=quchong(batches)
        for j in batches:
            for k in variables6[i]:
                if k[0]==j[0] and k[1]==j[1]:
                    k[2]=j[2]
                    j[2]+=1

    schedule=[[[] for j in range(n_machine_tool[i])] for i in range(n_machining_shop)] #reschdule[i][j][k] 调度信息   i是设备序号012...  j是操作号012... k是指代操作信息（0是操作序号，1是开始时间，2是结束时间）
    #调度信息，索引分别对应车间、机床、工序和信息，信息0表示工件号，1表示批次号，2表示工序号，3是开始时间，4是加工时间，5是结束时间,6是批次数，7是刀具号,8是机床号，9是刀具索引号，10是机床索引号
    schedule_assit=[[[[0 
                        for l in range(8)]
                      for k in range(n_job_operation_number[i])] 
                      for j in range(variables1[i])]
                    for i in range(n_job)]
    #调度辅助信息，索引分别对应工件，批次、工序所选的:车间、机床、刀具、开始时间、加工时间、结束时间、批次数、刀具号、机床索引号、刀具索引号、机床号

    #下面进行插入式解码

    for i in range(len(schedule)):#遍历每个车间
        for k in variables6[i]:#遍历每个工序
            gongjian0=k[0]
            pici0=k[1]
            gongxu0=k[2]
            piliang=variables2[gongjian0][pici0]
            chejian0=i
            jichuang_index=variables4[gongjian0][pici0][gongxu0]#可选机床索引
            jichuang0=n_job_operation_feasible_machines[gongjian0][gongxu0][chejian0][variables4[gongjian0][pici0][gongxu0]]#机床索引
            daoju_index=variables5[gongjian0][pici0][gongxu0]
            daoju0=n_job_operation_feasible_machines_tools[gongjian0][gongxu0][chejian0][jichuang_index][daoju_index]
            operationtime=Operationtime(gongjian0,piliang,gongxu0,chejian0,jichuang_index,daoju_index)
            start_time=0
            insert_index=0
            if len(schedule[i][jichuang0])==0:#如果是该机器上的第一个工序
                if k[2]==0:#如果是工件的第一个工序
                    start_time=0
                else:#如果不是工件的第一个工序
                    start_time=schedule_assit[gongjian0][pici0][gongxu0-1][5]#该工件批次的上一个工序的结束时间                                           
            else:
                gongxushuliang=len(schedule[chejian0][jichuang0])
                min_starttime=0
                if k[2]>0:
                    min_starttime=schedule_assit[gongjian0][pici0][gongxu0-1][5]#该工件批次的上一个工序的结束时间
                interval=[[max(schedule[chejian0][jichuang0][j-1][5],min_starttime),schedule[chejian0][jichuang0][j][3]] if j>0 else [min_starttime,schedule[chejian0][jichuang0][0][3]]
                          for j in range(gongxushuliang)]
                interval.append([max(schedule[chejian0][jichuang0][gongxushuliang-1][5],min_starttime),float('inf')])
                
                for j in range(len(interval)):
                    if interval[j][1]-interval[j][0]>=operationtime:
                        start_time=interval[j][0]
                        insert_index=j
                        break 
            schedule[i][jichuang0].insert(insert_index, [k[0],k[1],k[2],start_time,operationtime,start_time+operationtime,variables2[gongjian0][pici0],daoju0,jichuang0,daoju_index,jichuang_index])
            if len(schedule[i][jichuang0])==0:
                print(len(schedule[i][jichuang0]))
            schedule_assit[gongjian0][pici0][gongxu0]=[chejian0,jichuang0,daoju0,start_time,operationtime,start_time+operationtime,variables2[gongjian0][pici0],daoju0,jichuang_index,daoju_index,jichuang0]            
    makespan=[[[schedule[i][j][k][5]
                            for k in range(len(schedule[i][j]))]
                        for j in range(len(schedule[i]))]
                  for i in range(len(schedule))]
    makespan=totalmax(makespan)
    E_lu=totalsum([[[t_lu[schedule[i][j][k][0]][schedule[i][j][k][2]][i][schedule[i][j][k][10]]*schedule[i][j][k][6]*P_st[i][j] 
            for k in range(len(schedule[i][j]))] #工序
            for j in range(len(schedule[i]))] #机床
          for i in range(len(schedule))])#车间
    E_ts=totalsum([[[t_ts[schedule[i][j][k][0]][schedule[i][j][k][2]][i][schedule[i][j][k][10]][schedule[i][j][k][9]]*schedule[i][j][k][6]*P_st[i][j] 
            for k in range(len(schedule[i][j]))] 
            for j in range(len(schedule[i]))] 
          for i in range(len(schedule))])
    E_co=totalsum([[[t_co[schedule[i][j][k][0]][schedule[i][j][k][2]][i][schedule[i][j][k][10]][schedule[i][j][k][9]]*schedule[i][j][k][6]*(P_st[i][j]+P_ax[i][j]+ P_ac[schedule[i][j][k][0]][schedule[i][j][k][2]][i][schedule[i][j][k][10]][schedule[i][j][k][9]]+P_mr[schedule[i][j][k][0]][schedule[i][j][k][2]][i][schedule[i][j][k][10]][schedule[i][j][k][9]]+P_al[schedule[i][j][k][0]][schedule[i][j][k][2]][i][schedule[i][j][k][10]][schedule[i][j][k][9]])
            for k in range(len(schedule[i][j]))] 
            for j in range(len(schedule[i]))] 
          for i in range(len(schedule))])
    E_tc=totalsum([[[t_tc[schedule[i][j][k][0]][schedule[i][j][k][2]][i][schedule[i][j][k][10]][schedule[i][j][k][9]]*schedule[i][j][k][6]*P_st[i][j]*t_co[schedule[i][j][k][0]][schedule[i][j][k][2]][i][schedule[i][j][k][10]][schedule[i][j][k][9]]/T_tl[schedule[i][j][k][9]]
            for k in range(len(schedule[i][j]))] 
            for j in range(len(schedule[i]))] 
          for i in range(len(schedule))])
    E_is=totalsum2([[(makespan-sum([schedule[i][j][k][4]
            for k in range(len(schedule[i][j]))]))*P_st[i][j]  
            for j in range(len(schedule[i]))] 
          for i in range(len(schedule))])
    return [(E_lu+E_ts+E_co+E_tc+E_is)/3600000,makespan/3600,schedule]


Elist=[[0,0,0] for i in range(10)]
for i in range(len(Elist)):
    [Elist[i][0],Elist[i][1],Elist[i][2]]=fitness([random.randint(1, 10000)/10000 for i in range(n_variables)])
Elist=sorted(Elist,key=lambda x: x[0])

# for i in range(len(Elist)):
#     gantteplot(Elist[i][2],i)
# a1= [random.randint(1, 10000)/10000 for i in range(n_variables)]
# [E1,T1,schedule1]=fitness(a1)


# gantteplot(schedule,n_machining_shop)

