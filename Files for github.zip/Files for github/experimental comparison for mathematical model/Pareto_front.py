import sys 
sys.path.append("..") 
sys.path.append("E:/pyfiles/Commoncodes")
sys.path.append("E:/重大相关/个人资料/我的论文/分布式机械加工车间协同分批节能调度/python代码/experimental validation")
from Pareto_min import Pareto_min
import matplotlib.pyplot as plt
import numpy as np
import pandas as pd

string0="solution.xlsx"
solution2=(np.array(pd.read_excel("solution.xlsx",verbose=True,header=0)).tolist())
solution=[[solution2[i][1],solution2[i][2]] for i in range(len(solution2))]
[solution4,index]=Pareto_min(solution)
plt.grid()
plt.xlabel('Energy consumption/kWh')
plt.ylabel('Makespan time/h')
plt.plot([solution4[i][0]*10 for i in range(len(solution4))],[solution4[i][1] for i in range(len(solution4))], marker='*',color='black', linewidth=1, markersize=12, mec='w', mfc='r',label='The traditional method')
plt.rc('font',family='Times New Roman')

solution2=(np.array(pd.read_excel("solution2.xlsx",verbose=True,header=0)).tolist())
solution=[[solution2[i][1],solution2[i][2]] for i in range(len(solution2))]
[solution3,index]=Pareto_min(solution)

plt.plot([solution3[i][0]*10 for i in range(len(solution3))],[solution3[i][1] for i in range(len(solution3))], marker='*',color='black', linewidth=1, markersize=12, mec='w', mfc='b',label='The proposed method')
# plt.xticks([24600+i*(25400-24600)/5 for i in range(5)])

plt.legend()
plt.savefig("allcmp.svg",bbox_inches='tight')
plt.show()

solution3=np.array(solution3)
solution4=np.array(solution4)