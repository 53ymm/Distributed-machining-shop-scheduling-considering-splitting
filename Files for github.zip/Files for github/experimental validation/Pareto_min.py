def Pareto_min(solutions3):#返回最小值和最小者的索引
    optimal_f2=[]
    for i in solutions3:
      if not i in optimal_f2:
        optimal_f2.append(i)
    F2=[]
    for i in range(len(optimal_f2)):
        assis=[j for j in range(len(optimal_f2)) if i!=j]
        assis2=[assis[j] for j in range(len(assis)) if (optimal_f2[i][0]>=optimal_f2[assis[j]][0])&(optimal_f2[i][1]>=optimal_f2[assis[j]][1])]#找出j比i好的个体
        if len(assis2)==0 or optimal_f2[list(set(assis2))[0]]==optimal_f2[i]:#个体i没有被支配    
          F2=F2+[i]
    solutions2=[optimal_f2[F2[j]] for j in range(len(F2))]
    solutions3=sorted(solutions2,key=lambda x:x[0])
    return [solutions3,F2]