import sys 
sys.path.append("..") 
sys.path.append("E:/pyfiles/Commoncodes")
from Pareto_min import Pareto_min
import matplotlib.pyplot as plt
import numpy as np
import pandas as pd
import model
import math
string0="solution.xlsx"
solution2=(np.array(pd.read_excel("solution.xlsx",verbose=True,header=0)).tolist())
solution=[[solution2[i][1],solution2[i][2]] for i in range(len(solution2))]
[solution,index]=Pareto_min(solution)
plt.grid()
plt.xlabel('Energy consumption/kWh')
plt.ylabel('Makespan time/h')
plt.plot([solution[i][0]*10 for i in range(len(solution))],[solution[i][1] for i in range(len(solution))], marker='*',color='black', linewidth=1, markersize=12, mec='w', mfc='b',label='The Pareto front')
plt.rc('font',family='Times New Roman') 
plt.savefig("allcmp.svg",bbox_inches='tight')
plt.show()
# numb=len(solution)

# objective1=[0 for i in range(numb)]

# objective2=[0 for i in range(numb)]
# schedule=[0 for i in range(numb)]
# for i in range(numb):
#     encode=(np.array(pd.read_excel("encode.xlsx",verbose=True,header=0)).tolist())[index[i]]
#     [objective1[i],objective2[i],schedule[i]]=(model.fitness(encode))
# max1=max(objective1)
# min1=min(objective1)
# max2=max(objective2)
# min2=min(objective2)
# index0=0
# dist=6586876867876876
# for i in range(len(solution)):
#     diss=math.pow((solution[i][0]-min1)/(max1-min1), 2)+math.pow((solution[i][1]-min2)/(max2-min2),2)
#     if diss<dist:
#         dist=diss
#         index0=i
# print(index0)

# encode=(np.array(pd.read_excel("encode.xlsx",verbose=True,header=0)).tolist())[1112]
schedule=(model.fitness(encode))[2]
model.gantteplot(schedule,1)