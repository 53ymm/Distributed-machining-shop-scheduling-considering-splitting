import sys 
sys.path.append("..") 
sys.path.append("E:/pyfiles/Commoncodes")
from Pareto_min import Pareto_min
import numpy as np
import model

from pymoo.util.ref_dirs import get_reference_directions
from pymoo.core.problem import ElementwiseProblem
from pymoo.optimize import minimize
import pandas as pd
from pymoo.termination import get_termination
import threading



from pymoo.algorithms.moo.nsga2 import NSGA2

class myThread(threading.Thread):  # 继承父类threading.Thread
   def __init__(self, threadID, name, counter, repitnum):
      threading.Thread.__init__(self)
      self.threadID = threadID
      self.name = name
      self.counter = counter
      self.repitnum = repitnum

   def run(self):  # 把要执行的代码写到run函数里面 线程在创建后会直接运行run函数
       for i in range(5):
        CPUtime=8*3600/5
        termination = get_termination("time", CPUtime)
        res = minimize(problem,
                      algorithm,
                      termination,
                      # seed=i,
                      verbose=False)
        solutions[self.threadID-1]=solutions[self.threadID-1]+res.F.tolist()
        
        Encode[self.threadID-1]=Encode[self.threadID-1]+res.X.tolist()

n_va=model.n_variables

class MyProblem(ElementwiseProblem):

    def __init__(self):
        super().__init__(n_var=n_va,
                         n_obj=2,
                         n_constr=0,
                         xl=np.array([0.00000001 for i in range(n_va)]),
                         xu=np.array([1 for i in range(n_va)]))

    def _evaluate(self, x, out, *args, **kwargs):
        fitness=model.fitness(x.tolist())
        ec = fitness[0]
        tt = fitness[1]
        out["F"] = [ec, tt]


    
problem = MyProblem()

def write_excel_fun(content,name0):
    y=content
    data=pd.DataFrame(y)
    writer = pd.ExcelWriter(name0+'.xlsx')		# 写入Excel文件
    data.to_excel(writer, 'page_1', float_format='%.5f')		# ‘page_1’是写入excel的sheet名
    writer.save()

algorithm = NSGA2(pop_size=50)

solutions=[[] for i in range(5)]
Encode=[[] for i in range(5)]


    


thread1 = myThread(1, "Thread-1", 1,1)
thread2 = myThread(2, "Thread-2", 2,2)
thread3 = myThread(3, "Thread-3", 3,3)
thread4 = myThread(4, "Thread-4", 4,4)
thread5 = myThread(5, "Thread-5", 5,5)

# 开启线程
thread1.start()
thread2.start()
thread3.start()
thread4.start()
thread5.start()

# 等待线程结束
thread1.join()
thread2.join()
thread3.join()
thread4.join()
thread5.join()



solution1= []
encode1=[]
for i in range(5):
    solution1=solution1+solutions[i]
    encode1=encode1+Encode[i]
write_excel_fun(np.array(solution1),'solution')
write_excel_fun(np.array(encode1),'encode')
# for i in range(5):
#     # def write_excel_fun(content,name0,sheetname1):
#     y=np.array(solutions[i])
#     data=pd.DataFrame(y)
#     data.to_excel(writer,  float_format='%.5f',sheet_name=str(i))		# ‘page_1’是写入excel的sheet名
# writer.save()
    
# writer = pd.ExcelWriter('encode.xlsx')		# 写入Excel文件
# for i in range(5):
#     # def write_excel_fun(content,name0,sheetname1):
#     y=np.array(Encode[i])
#     data=pd.DataFrame(y)
#     data.to_excel(writer,  float_format='%.5f',sheet_name=str(i))		# ‘page_1’是写入excel的sheet名
# writer.save()