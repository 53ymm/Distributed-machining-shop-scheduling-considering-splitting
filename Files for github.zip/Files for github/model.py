import matplotlib.pyplot as plt
import copy
import random
import pandas as pd
import numpy as np
random.seed(1)
Operations_data=np.array(pd.read_excel('data.xlsx',sheet_name='Operations')).tolist()
Machine_tools_data=np.array(pd.read_excel('data.xlsx',sheet_name='Machine tools')).tolist()
Cutting_tools_data=np.array(pd.read_excel('data.xlsx',sheet_name='Cutting tools')).tolist()

def quchong(fitnesspop):#返回元素
    optimal_f2=[]
    for i in fitnesspop:
      if not i in optimal_f2:
        optimal_f2.append(i)
    return optimal_f2


#案例数据
n_machining_shop=max([Machine_tools_data[i][0] for i in range(len(Machine_tools_data))]) #分布式机械加工车间的数量
n_machine_tool=[0 for i in range(n_machining_shop)] #各分布式机械加工车间的机床数量
for i in range(len(Machine_tools_data)):
    n_machine_tool[Machine_tools_data[i][0]-1]=max(n_machine_tool[Machine_tools_data[i][0]-1],Machine_tools_data[i][1])

       


c0=[[Machine_tools_data[sum(n_machine_tool[:i])+j][5]  
     for j in range(n_machine_tool[i])] 
    for i in range(len(n_machine_tool))]

c1=[[Machine_tools_data[sum(n_machine_tool[:i])+j][6] 
     for j in range(n_machine_tool[i])] 
    for i in range(len(n_machine_tool))]

 
#附加载荷损耗功率的系数c0和c1
n_job=max([Operations_data[i][0] for i in range(len(Operations_data))]) #工件种类




n_tool=len(Cutting_tools_data)#刀具数量

n_job_operation_number=[0 
                        for i in range(n_job)] #各工件的工序数量
for i in range(len(Operations_data)):
    n_job_operation_number[Operations_data[i][0]-1]=max(n_job_operation_number[Operations_data[i][0]-1],Operations_data[i][3])

n_job_number=[Operations_data[sum(n_job_operation_number[:i])][2]
              for i in range(n_job)] #各工件所需的数量
n_batches_min=[Operations_data[sum(n_job_operation_number[:i])][14] 
               for i in range(n_job)]
n_batches_max=[Operations_data[sum(n_job_operation_number[:i])][15] 
               for i in range(n_job)]

n_job_feasible_shops=[[j for j in range(n_machining_shop)] for i in range(n_job)]#各个工件可选的车间
# n_job_operation_feasible_machines=[[[random.sample(list(range(n_machine_tool[k])),random.randint(2, n_machine_tool[k]))
#                                      for k in range(n_machining_shop)] 
#                                     for j in range(n_job_operation_number[i])] 
#                                    for i in range(n_job)]
#各工件的工序可选机床,四个索引分别对应工件、工序、车间、机床
n_job_operation_feasible_machines=[[[[]
                                     for k in range(n_machining_shop)] 
                                    for j in range(n_job_operation_number[i])] 
                                   for i in range(n_job)]

for i in range(n_job):#工件
    for j in range(n_job_operation_number[i]):#工序
        for k in range(n_machining_shop):#车间
            string0=Operations_data[sum(n_job_operation_number[:i])+j][6]
            b=string0.split(",")
            intlist=[[int( b[l][1])-1 ,int( b[l][2:])-1] for l in range(len(b))]
            n_job_operation_feasible_machines[i][j][k]=[intlist[l][1] for l in range(len(intlist)) if k==intlist[l][0] ]

n_job_operation_feasible_tools=[[[]
        for k in range(len(n_job_operation_feasible_machines[i]))]
    for i in range(len(n_job_operation_feasible_machines))]

for i in range(len(n_job_operation_feasible_tools)):
    for k in range(len(n_job_operation_feasible_tools[i])):
         string0=Operations_data[sum(n_job_operation_number[:i])+k][7]
         b=string0.split(",") 
         intlist=[int( b[l][1:])-1 for l in range(len(b))]
         n_job_operation_feasible_tools[i][k]=[intlist[l] for l in range(len(intlist))]

n_job_operation_feasible_machines_tools=[[[[]
                                           for j in range(len(n_machine_tool))] 
                                          for k in range(n_job_operation_number[i])]
                                         for i in range(n_job)]
#各工件的工序在各机床上的可选刀具,五个索引分别对应工件、工序、车间、机床、刀具
def data_set(input0):
    t_ts=[[[[[0
          for m in range(len(n_job_operation_feasible_machines_tools[i][j][k][l]))]
          for l in range(len(n_job_operation_feasible_machines_tools[i][j][k]))]
        for k in range(len(n_job_operation_feasible_machines_tools[i][j]))] 
        for j in range(len(n_job_operation_feasible_machines_tools[i]))] 
      for i in range(len(n_job_operation_feasible_machines_tools))]
    for i in range(len(n_job_operation_feasible_machines)):
        for j in range(len(n_job_operation_feasible_machines[i])):
            index0=sum(n_job_operation_number[:i])+j
            toolstring=Operations_data[index0][7]
            if ',' not in toolstring:
                t_tslist=(Operations_data[index0][input0]).replace("],[", "")
                toollist=(Operations_data[index0][7].replace("T", "")).split(',')
                toollist=[int(k)-1 for k in toollist]
                # machinelist0=((Operations_data[index0][6].strip('[]').replace("M", ""))).split(',')
                # machinelist=[[int(machinelist0[k][0])-1,int(machinelist0[k][1:])-1] for k in range(len(machinelist0))]
                t_tsstring=(t_tslist.strip('[]')).split(',')
                for k in range(len(t_ts[i][j])):
                    for l in range(len(t_ts[i][j][k])):
                        t_ts[i][j][k][l][0]=int(t_tsstring[0])
                        del(t_tsstring[0])
            else:
                toollist=(Operations_data[index0][7].replace("T", "")).split(',')
                toollist=[int(k)-1 for k in toollist]
                # machinelist0=((Operations_data[index0][6].strip('[]').replace("M", ""))).split(',')
                # machinelist=[[int(machinelist0[k][0])-1,int(machinelist0[k][1:])-1] for k in range(len(machinelist0))]
                t_tslist=(Operations_data[index0][input0])
                t_tsstringlen=len(t_tslist)
                t_tsstring=t_tslist[1:t_tsstringlen-1].split('],[')
                t_tsstring[0]=t_tsstring[0][1:]
                t_tsstring[-1]=t_tsstring[-1][:-1]
                for k in range(len(t_tsstring)):
                    t_tsstring[k]=t_tsstring[k].split(',')
                    t_tsstring[k]=[int(t_tsstring[k][l]) for l in range(len(t_tsstring[k]))]
                for k in range(len(t_ts[i][j])):
                    for l in range(len(t_ts[i][j][k])):
                            t_ts[i][j][k][l]=t_tsstring[0]
                            del(t_tsstring[0])
    return t_ts

for i in range(n_job):
    for k in range(n_job_operation_number[i]):
        index0=sum(n_job_operation_number[:i])+k
        machines=(Operations_data[index0][6].replace("M", "")).split(',')
        tool0=(Operations_data[index0][7].replace("T", "")).split(',')
        tool0=[int(tool0[l])-1 for l in range(len(tool0))]
        machine0=[[] for l in range(n_machining_shop)]
        for l in range(len(machines)):
            machine0[int(machines[l][0])-1].append(int(machines[l][1])-1)
        for j in range(len(machine0)):#每个车间
            n_job_operation_feasible_machines_tools[i][k][j]=[tool0  for l in range(len(machine0[j]))]
                                         

#下面这些需要处理
t_lu=[[[[0
          for l in range(len(n_job_operation_feasible_machines[i][j][k]))] 
        for k in range(len(n_job_operation_feasible_machines[i][j]))] 
        for j in range(len(n_job_operation_feasible_machines[i]))] 
      for i in range(len(n_job_operation_feasible_machines))]
for i in range(len(n_job_operation_feasible_machines)):
    for j in range(len(n_job_operation_feasible_machines[i])):
        t_lulist=(Operations_data[sum(n_job_operation_number[:i])+j][12].strip('[]')).split(',')
        for k in range(len(n_job_operation_feasible_machines[i][j])):
            for l in range(len(n_job_operation_feasible_machines[i][j][k])):
                t_lu[i][j][k][l]=int(t_lulist[0])
                del (t_lulist[0])
#各工件工序在各机床上的安装卸载时间之和,t_lu[i][j][k][m]是工件i的工序j在车间k的机床m的安装和拆卸时间之和
t_ts=data_set(13)#各工件工序在各机床上各刀具的对刀时间,t_ts[i][j][k][l][m]是工件i的工序j在车间k的机床l的采用刀具m的对刀时间
t_co=data_set(10)#各工件工序在各机床上采用各刀具的切削时间,t_co[i][j][k][l][m]是工件i的工序j在车间k的机床l的采用刀具m的切削时间
t_tc=data_set(11)#各工件工序在各机床上采用各刀具的换刀时间,t_tc[i][j][k][l][m]是工件i的工序j在车间k的机床l的采用刀具m的切削时间
P_mr=data_set(8)#各车间机床的物料去除功率,[i][j][k][l][m]分别对应工件、工序、车间、机床、刀具
P_ac=data_set(9)#各车间机床的空载功率,[i][j][k]分别对应车间、机床、刀具的编号*********这个有问题

P_st=[[0
        for j in range(n_machine_tool[i])]
      for i in range(len(n_machine_tool))]
for i in range(len(Machine_tools_data)):
        P_st[Machine_tools_data[i][0]-1][Machine_tools_data[i][1]-1]=Machine_tools_data[i][3]



P_ax=[[0 
        for j in range(n_machine_tool[i])]
      for i in range(len(n_machine_tool))]
for i in range(len(Machine_tools_data)):
        P_ax[Machine_tools_data[i][0]-1][Machine_tools_data[i][1]-1]=Machine_tools_data[i][4]
#各车间机床的待机功率、辅助设备功率,[i][j]分别对应车间号和机床号



T_tl=[Cutting_tools_data[i][4]*60 for i in range(len(Cutting_tools_data))]
# #各个刀具的寿命，索引分别是工件、工序、车间、机床、刀具





P_al=[[[[[c0[k][l]*P_mr[i][j][k][l][m]+
          P_mr[i][j][k][l][m]*P_mr[i][j][k][l][m]*c1[k][l]
          for m in range(len(n_job_operation_feasible_machines_tools[i][j][k][l]))] 
          for l in range(len(n_job_operation_feasible_machines_tools[i][j][k]))] 
        for k in range(len(n_job_operation_feasible_machines_tools[i][j]))] 
        for j in range(len(n_job_operation_feasible_machines_tools[i]))]
      for i in range(len(n_job_operation_feasible_machines_tools))]
#各车间机床的附加载荷损耗功率,[i][j][k][l][m]分别对应工件、工序、车间、机床、刀具


# #案例数据，需要根据事情情况修改****************************

n_variables_1=sum(n_batches_max)
n_variables_2=sum([n_batches_max[i]*n_job_operation_number[i] for i in range(n_job)])
n_variables=n_variables_1*3+n_variables_2*3
#变量数量，分别是:
#    订单分批的批次数量
#    订单各批次的工件数量
#    批次分配车间的情况
#    各批次工序选择机床的情况
#    各批次工序选择刀具的情况
#    各批次工序加工顺序的情况
def totalsum(input0):#能耗求和，最大阶级是3
    return0=0
    for i in range(len(input0)):
        for j in range(len(input0[i])):
            for k in range(len(input0[i][j])):
                    return0=return0+input0[i][j][k]
    return return0

def totalsum2(input0):#能耗求和，最大阶级是3
    return0=0
    for i in range(len(input0)):
        for j in range(len(input0[i])):
                    return0=return0+input0[i][j]
    return return0

def getBrightColor():
    # 获得亮色，保证其中两色分别90和ff，第三色为任意值即可
    full_range = ["0","1","2","3","4","5","6","7","8","9","a","b","c","d","e","f"]
    combination = ["90"]
    # 将 ff 随机插入 90 前或后
    combination.insert(random.randint(0,1),"ff")
    third_color = "{0}{1}".format(full_range[random.randint(0,15)],full_range[random.randint(0,15)])
    combination.insert(random.randint(0,2),third_color)
    color = "#" + "".join(combination)
    return color

def totalmax(input0):#时间的最大值，最大阶级是3
    return0=0
    for i in range(len(input0)):
        for j in range(len(input0[i])):
            for k in range(len(input0[i][j])):
                if return0<input0[i][j][k]:
                    return0=input0[i][j][k]
    return return0
    
def Operationtime(gongjian,piliang,gongxu,chejian,jichuang,daoju):
    t_lu0=t_lu[gongjian][gongxu][chejian][jichuang]*piliang
    t_ts0=(t_ts[gongjian][gongxu][chejian][jichuang][daoju])*piliang*(t_co[gongjian][gongxu][chejian][jichuang][daoju])/(T_tl[daoju])
    t_co0=t_co[gongjian][gongxu][chejian][jichuang][daoju]*piliang
    t_tc0=t_tc[gongjian][gongxu][chejian][jichuang][daoju]*piliang*t_co[gongjian][gongxu][chejian][jichuang][daoju]/T_tl[daoju]
    return t_lu0+t_ts0+t_co0+t_tc0
    

def endingtime(startingtime, job,operation, batch,jobshop,machinetool,tool):
    return startingtime+batch*t_lu[job][operation][jobshop][machinetool]+t_ts[job][operation][jobshop][machinetool][tool]*batch*t_co[job][operation][jobshop][machinetool][tool]/T_tl[tool]+t_co[tool]*batch+t_tc[job][operation][jobshop][machinetool][tool]*batch*t_co[job][operation][jobshop][machinetool][tool]/T_tl[tool]

def vector12vector2(vector1,distri):#一维向量转二维向量，输入分别是一维向量和分布情况
    assit=0
    return0=[0 for i in range(len(distri))]
    for i in range(len(distri)):
        return0[i]=vector1[assit:assit+distri[i]]
        assit+=distri[i]
    return return0

def vector12vector3(vector1,distri):#一维向量转二维向量，输入分别是一维向量和分布情况
    assit=0
    return0=[[0 for j in range(len(distri[i]))] for i in range(len(distri))]
    for i in range(len(distri)):
        for j in range(len(distri[i])):
            return0[i][j]=vector1[assit:
                                  assit+len(distri[i][j])]
        assit+=len(distri[i][j])
    return return0 


def fitnesspopfun(pop):
    return [fitness(i)[0:2] for i in pop]

def gantteplot(schedule,num):
    fig, axs = plt.subplots(n_machining_shop)

    picis=[0 for j in range(n_job)]#每个工件分了多少批次
    color_asit=[[]for i in range(n_job)]#颜色辅助变量
    color=[[]for i in range(n_machining_shop)]#颜色区分
    MS=[[]for i in range(n_machining_shop)]#机器编号
    T = [[]for i in range(n_machining_shop)]#操作持续时间
    macStartTime = [[]for i in range(n_machining_shop)]#操作开始时间
    J = [[]for i in range(n_machining_shop)]#工件号
    B=[[]for i in range(n_machining_shop)]#批次号
    oper = [[]for i in range(n_machining_shop)]#工序号

        
    
    for i in range(len(schedule)):#访问各个车间
        for j in schedule[i]:#访问各个机床
            for k in j:#访问各个操作
                MS[i].append(k[8])#机器号
                T[i].append(k[4])#操作持续时间
                macStartTime[i].append(k[3])#操作开始时间
                J[i].append(k[0]+1)#工件号
                B[i].append(k[1]+1)#批次号
                oper[i].append(k[2]+1)#工序号
                picis[k[0]]=max(picis[k[0]],k[1]+1)
    for i in range(len(picis)):#访问各个工件
        color_asit[i]=[getBrightColor() for k in range(picis[i])]
        # 画图
        
    batches=[[] for i in range(n_machining_shop)]
    for i in range(len(schedule)):#访问各个车间
        for j in schedule[i]:#访问各个机床
            for k in j:#访问各个操作
                if [k[0]+1,k[1]+1] not in batches[i]:
                    batches[i].append([k[0]+1,k[1]+1])
        batches[i].sort(key=lambda x: x[0]*100+x[1])

    for i in range(len(schedule)):#访问各个车间
        for j in schedule[i]:#访问各个机床
            for k in j:#访问各个操作
                color[i].append(color_asit[k[0]][k[1]])
    for i in range(len(schedule)):#访问各个车间
        gantt(axs[i],MS[i], T[i], macStartTime[i], J[i], B[i],oper[i],color[i])
        for j in range(len(batches[i])):
            x1=int(j/n_machine_tool[i])
            y1=j%n_machine_tool[i]
            axs[i].barh(y1,400,0.5,left=63000+x1*3000,color=color_asit[batches[i][j][0]-1][batches[i][j][1]-1])
            axs[i].text(64000+x1*3000-500, y1-0.4, '%s-%s' %
                  (batches[i][j][0],batches[i][j][1]), size=8)
            
        axs[i].set_yticks([])
        if i<3:
            axs[i].set_xticks([])
        else:
            axs[i].set_xticks([0,20000,40000,60000])
        # ax=axs[i]
        
    print(batches)
    plt.rcParams.update({'font.size': 4})
    plt.tight_layout()
    plt.savefig("allcmp"+str(num)+".svg",bbox_inches='tight') 
    plt.show()


def gantt(axs0,MS, T, macStartTime, workpiece,B, operation,colors):
    maxtime=max([T[i]+macStartTime[i] for i in range(len(T))])
    for i in range(len(MS)):
        axs0.barh(MS[i],T[i],0.5,left=macStartTime[i],color=colors[i])
        # axs0.text(macStartTime[i] + T[i] / 2-maxtime*0.01, MS[i]-0.10, '%s-%s' %
        #           (workpiece[i],B[i]), size=4)
        # figure0.xticks(fontsize=6) 
    # yticks_assit=['$M_{'+str(i+1)+'}$' for i in range(len(quchong(MS)))]
    # figure0.yticks(range(len(set(MS))), yticks_assit)

def fitness(individual0):#评价个体，给出对应的目标函数
    individual=copy.deepcopy(individual0)# individual0.tolist()#这个可能不需要
    variables1_encode=individual[0:n_variables_1]    
    variables2_encode=individual[n_variables_1:2*n_variables_1]    
    variables3_encode=individual[2*n_variables_1:3*n_variables_1]    
    variables4_encode=individual[3*n_variables_1:3*n_variables_1+n_variables_2]    
    variables5_encode=individual[3*n_variables_1+n_variables_2:3*n_variables_1+2*n_variables_2]    
    variables6_encode=individual[3*n_variables_1+2*n_variables_2:]
    variables1_assit1=[0 if variables1_encode[i]<0.5 else 1 for i in range(len(variables1_encode))]
    variables1_assit2=vector12vector2(variables1_assit1,n_batches_max)
    variables1=[max(sum(variables1_assit2[i]),n_batches_min[i])  for i in range(len(variables1_assit2))]
    #第一个变量nj_i，各工件的批次数量

    variables2_assit1=vector12vector2(variables2_encode,n_batches_max)
    variables2=[[0 for j in range(variables1[i])] for i in range(len(variables1))]
    #第二个变量nb_ij，各批次里的工件数量
    for i in range(len(variables1)):
        assit0=variables2_assit1[i][0:variables1[i]]#第i个工件各批次的随机键
        for j in range(variables1[i]):
            if j< (variables1[i]-1):
                variables2[i][j]=max((int)(n_job_number[i]*assit0[j]/sum(assit0)),1) 
            else:
                variables2[i][j]=n_job_number[i]-sum(variables2[i])
    variables3_assit1=vector12vector2(variables3_encode,n_batches_max)
    variables3=[[0 for j in range(variables1[i])] for i in range(len(variables1))]
    #第三个变量nb_ij，各工序所选车间，索引分别包括工件，批次
    for i in range(len(variables1)):
        for j in range(variables1[i]):
            variables3[i][j]=(int)(variables3_assit1[i][j]*len(n_job_feasible_shops[i]))
            if variables3[i][j]==len(n_job_feasible_shops[i]):
                    variables3[i][j]-=1
    distrib1=[[[0
                for k in range(n_job_operation_number[i])]
                for j in range(variables1[i])]
              for i in range(n_job)]
    variables4_assit1=vector12vector3(variables4_encode,distrib1)
    variables4=copy.deepcopy(variables4_assit1)
    #第四个变量，各工序选择机床的情况，三个索引分别代表工件、批次、工序所对应的可选机床索引
    for i in range(len(variables4_assit1)):#工件
        for j in range(len(variables4_assit1[i])):#批次
            for k in range(len(variables4_assit1[i][j])):#工序
                variables4[i][j][k]=(int)(variables4_assit1[i][j][k]*len(n_job_operation_feasible_machines[i][k][variables3[i][j]]))
                if variables4[i][j][k]==len(n_job_operation_feasible_machines[i][k][variables3[i][j]]):
                    variables4[i][j][k]-=1
                #上面的是实际机床编号
    distrib2=[[[0
                for k in range(n_job_operation_number[i])] 
                for j in range(variables1[i])]
              for i in range(n_job)]
    variables5_assit1=vector12vector3(variables5_encode,distrib2)
    variables5=copy.deepcopy(variables4_assit1)
    #第五个变量，各工序选择刀具的情况，三个索引分别代表工件、批次、工序,所对应的可选刀具索引

    for i in range(len(variables4_assit1)):#工件
        for j in range(len(variables4_assit1[i])):#批次
            for k in range(len(variables4_assit1[i][j])):#工序
                variables5[i][j][k]=(int)(variables5_assit1[i][j][k]*len(n_job_operation_feasible_machines_tools[i][k][variables3[i][j]][variables4[i][j][k]]))
                if variables5[i][j][k]==len(n_job_operation_feasible_machines_tools[i][k][variables3[i][j]][variables4[i][j][k]]):
                    variables5[i][j][k]-=1
    distrib3=[[[0 
                for k in range(n_job_operation_number[i])] 
                for j in range(variables1[i])]
              for i in range(n_job)]
    variables6_assit1=vector12vector3(variables6_encode,distrib3)    
    # variables6=copy.deepcopy(variables4_assit1)#第五个变量，各工序选择刀具的情况，三个索引分别代表工件、批次、工序所对应的可选刀具索引
    operations_assit=[[]
                      for i in range(n_machining_shop)]#各个车间待调度的工序
    sequence_encode=[[]
                      for i in range(n_machining_shop)]#各个车间待调度工序顺序的编码
    
    for i in range(len(variables1)):
        for j in range(variables1[i]):
            for k in range(n_job_operation_number[i]):
                operations_assit[variables3[i][j]].append([i,j,k])
                sequence_encode[variables3[i][j]].append(variables6_assit1[i][j][k])
    sequence_assit=[[j
                      for j in range(len(sequence_encode[i]))]
                    for i in range(n_machining_shop)]#各个车间待调度工序顺序的编码
    operations=[[]
                for i in range(n_machining_shop)]
    for i in range(n_machining_shop):
        sequence_assit[i].sort(key = lambda x: sequence_encode[i][x])
        operations[i]=[operations_assit[i][sequence_assit[i][j]] 
                        for j in range(len(sequence_assit[i]))]

    # operations2=[[0 for j in range(variables1[i])] for i in range(n_job)]#各车间待调度的工序
    variables6=copy.deepcopy(operations)
    #第六个变量：各车间待调度工序的加工顺序，第一个索引是车间，第二个索引是第几个待调度的工序，第三个索引的0 1 2分别是工件、批次、工序
    for i in range(len(variables6)):
        batches=[]
        for j in variables6[i]:
            batches.append([j[0],j[1],0])
        batches=quchong(batches)
        for j in batches:
            for k in variables6[i]:
                if k[0]==j[0] and k[1]==j[1]:
                    k[2]=j[2]
                    j[2]+=1

    schedule=[[[] for j in range(n_machine_tool[i])] for i in range(n_machining_shop)] #reschdule[i][j][k] 调度信息   i是设备序号012...  j是操作号012... k是指代操作信息（0是操作序号，1是开始时间，2是结束时间）
    #调度信息，索引分别对应车间、机床、工序和信息，信息0表示工件号，1表示批次号，2表示工序号，3是开始时间，4是加工时间，5是结束时间,6是批次数，7是刀具号,8是机床号，9是刀具索引号，10是机床索引号
    schedule_assit=[[[[0 
                        for l in range(8)]
                      for k in range(n_job_operation_number[i])] 
                      for j in range(variables1[i])]
                    for i in range(n_job)]
    #调度辅助信息，索引分别对应工件，批次、工序所选的:车间、机床、刀具、开始时间、加工时间、结束时间、批次数、刀具号、机床索引号、刀具索引号、机床号

    #下面进行插入式解码

    for i in range(len(schedule)):#遍历每个车间
        for k in variables6[i]:#遍历每个工序
            gongjian0=k[0]
            pici0=k[1]
            gongxu0=k[2]
            piliang=variables2[gongjian0][pici0]
            chejian0=i
            jichuang_index=variables4[gongjian0][pici0][gongxu0]#可选机床索引
            jichuang0=n_job_operation_feasible_machines[gongjian0][gongxu0][chejian0][variables4[gongjian0][pici0][gongxu0]]#机床索引
            daoju_index=variables5[gongjian0][pici0][gongxu0]
            daoju0=n_job_operation_feasible_machines_tools[gongjian0][gongxu0][chejian0][jichuang_index][daoju_index]
            operationtime=Operationtime(gongjian0,piliang,gongxu0,chejian0,jichuang_index,daoju_index)
            start_time=0
            insert_index=0
            if len(schedule[i][jichuang0])==0:#如果是该机器上的第一个工序
                if k[2]==0:#如果是工件的第一个工序
                    start_time=0
                else:#如果不是工件的第一个工序
                    start_time=schedule_assit[gongjian0][pici0][gongxu0-1][5]#该工件批次的上一个工序的结束时间                                           
            else:
                gongxushuliang=len(schedule[chejian0][jichuang0])
                min_starttime=0
                if k[2]>0:
                    min_starttime=schedule_assit[gongjian0][pici0][gongxu0-1][5]#该工件批次的上一个工序的结束时间
                interval=[[max(schedule[chejian0][jichuang0][j-1][5],min_starttime),schedule[chejian0][jichuang0][j][3]] if j>0 else [min_starttime,schedule[chejian0][jichuang0][0][3]]
                          for j in range(gongxushuliang)]
                interval.append([max(schedule[chejian0][jichuang0][gongxushuliang-1][5],min_starttime),float('inf')])
                
                for j in range(len(interval)):
                    if interval[j][1]-interval[j][0]>=operationtime:
                        start_time=interval[j][0]
                        insert_index=j
                        break 
            schedule[i][jichuang0].insert(insert_index, [k[0],k[1],k[2],start_time,operationtime,start_time+operationtime,variables2[gongjian0][pici0],daoju0,jichuang0,daoju_index,jichuang_index])
            if len(schedule[i][jichuang0])==0:
                print(len(schedule[i][jichuang0]))
            schedule_assit[gongjian0][pici0][gongxu0]=[chejian0,jichuang0,daoju0,start_time,operationtime,start_time+operationtime,variables2[gongjian0][pici0],daoju0,jichuang_index,daoju_index,jichuang0]            
    makespan=[[[schedule[i][j][k][5]
                            for k in range(len(schedule[i][j]))]
                        for j in range(len(schedule[i]))]
                  for i in range(len(schedule))]
    makespan=totalmax(makespan)
    E_lu=totalsum([[[t_lu[schedule[i][j][k][0]][schedule[i][j][k][2]][i][schedule[i][j][k][10]]*schedule[i][j][k][6]*P_st[i][j] 
            for k in range(len(schedule[i][j]))] #工序
            for j in range(len(schedule[i]))] #机床
          for i in range(len(schedule))])#车间
    E_ts=totalsum([[[t_ts[schedule[i][j][k][0]][schedule[i][j][k][2]][i][schedule[i][j][k][10]][schedule[i][j][k][9]]*schedule[i][j][k][6]*P_st[i][j] 
            for k in range(len(schedule[i][j]))] 
            for j in range(len(schedule[i]))] 
          for i in range(len(schedule))])
    E_co=totalsum([[[t_co[schedule[i][j][k][0]][schedule[i][j][k][2]][i][schedule[i][j][k][10]][schedule[i][j][k][9]]*schedule[i][j][k][6]*(P_st[i][j]+P_ax[i][j]+ P_ac[schedule[i][j][k][0]][schedule[i][j][k][2]][i][schedule[i][j][k][10]][schedule[i][j][k][9]]+P_mr[schedule[i][j][k][0]][schedule[i][j][k][2]][i][schedule[i][j][k][10]][schedule[i][j][k][9]]+P_al[schedule[i][j][k][0]][schedule[i][j][k][2]][i][schedule[i][j][k][10]][schedule[i][j][k][9]])
            for k in range(len(schedule[i][j]))] 
            for j in range(len(schedule[i]))] 
          for i in range(len(schedule))])
    E_tc=totalsum([[[t_tc[schedule[i][j][k][0]][schedule[i][j][k][2]][i][schedule[i][j][k][10]][schedule[i][j][k][9]]*schedule[i][j][k][6]*P_st[i][j]*t_co[schedule[i][j][k][0]][schedule[i][j][k][2]][i][schedule[i][j][k][10]][schedule[i][j][k][9]]/T_tl[schedule[i][j][k][9]]
            for k in range(len(schedule[i][j]))] 
            for j in range(len(schedule[i]))] 
          for i in range(len(schedule))])
    E_is=totalsum2([[(makespan-sum([schedule[i][j][k][4]
            for k in range(len(schedule[i][j]))]))*P_st[i][j]  
            for j in range(len(schedule[i]))] 
          for i in range(len(schedule))])
    return [(E_lu+E_ts+E_co+E_tc+E_is)/3600000,makespan/3600,schedule]


# Elist=[[0,0,0] for i in range(10)]
# for i in range(len(Elist)):
#     [Elist[i][0],Elist[i][1],Elist[i][2]]=fitness([random.randint(1, 10000)/10000 for i in range(n_variables)])
# Elist=sorted(Elist,key=lambda x: x[0])

# for i in range(len(Elist)):
#     gantteplot(Elist[i][2],i)
# a1= [random.randint(1, 10000)/10000 for i in range(n_variables)]
# [E1,T1,schedule1]=fitness(a1)


# gantteplot(schedule,n_machining_shop)

