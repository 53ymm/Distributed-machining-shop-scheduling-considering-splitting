import sys 
sys.path.append("..") 
sys.path.append("E:/pyfiles/Commoncodes")
from Pareto_min import Pareto_min

import numpy as np
import model

from pymoo.util.ref_dirs import get_reference_directions
from pymoo.core.problem import ElementwiseProblem
from pymoo.optimize import minimize
import pandas as pd
from pymoo.termination import get_termination

from pymoo.indicators.hv import HV

from pymoo.algorithms.moo.moead import MOEAD



n_va=model.n_variables

class MyProblem(ElementwiseProblem):

    def __init__(self):
        super().__init__(n_var=n_va,
                         n_obj=2,
                         n_constr=0,
                         xl=np.array([0.00000001 for i in range(n_va)]),
                         xu=np.array([1 for i in range(n_va)]))

    def _evaluate(self, x, out, *args, **kwargs):
        fitness=model.fitness(x.tolist())
        ec = fitness[0]
        tt = fitness[1]
        out["F"] = [ec, tt]
ref_dirs = get_reference_directions("das-dennis", 2, n_partitions=50)

def write_excel_fun(content,generations,repitnum, name0):
    y=content
    data=pd.DataFrame(y)
    writer = pd.ExcelWriter(name0+str(generations)+'   '+str(repitnum)+'  .xlsx')		# 写入Excel文件
    data.to_excel(writer, 'page_1', float_format='%.5f')		# ‘page_1’是写入excel的sheet名
    writer.save()
    
problem = MyProblem()



algorithm = MOEAD(
    ref_dirs,
    n_neighbors=15,
    prob_neighbor_mating=0.7,
)

solutions=[]


for i in range(10):
    CPUtime=60
    termination = get_termination("time", CPUtime)
    res = minimize(problem,
                  algorithm,
                  termination,
                  seed=i,
                  verbose=False)
    solutions=solutions+res.F.tolist()
    
hv = HV(ref_point=np.array([300, 30]))

hv_metric_value=hv(np.array(Pareto_min(solutions)[0]))

# for i in range(len(solutions)):
#     res = minimize(problem,
#                  algorithm,
#                  termination,
#                  verbose=False)
#     write_excel_fun(res.F,CPUtime,0,'F')


