import sys 
sys.path.append("..") 
sys.path.append("E:/pyfiles/Commoncodes")
from Pareto_min import Pareto_min
import mobsa
import model as model
import matplotlib.pyplot as plt
import numpy as np
from pymoo.indicators.hv import HV
popsize=50
dim=model.n_variables
low=[0 for i in range(dim)]
up=[1 for i in range(dim)]
DIM_RATE=1


solutions=[]


for i in range(10):
    CPUtime=60
    result0=(mobsa.mobsa1(popsize,dim,DIM_RATE,low,up,CPUtime))[1]
    solutions=solutions+result0
    
hv = HV(ref_point=np.array([300, 30]))

hv_metric_value=hv(np.array(Pareto_min(solutions)[0]))

# result0=mobsa.mobsa1(popsize,dim,DIM_RATE,low,up,epoch)
# solution=sorted(result0[1],key=lambda x: x[0])


# plt.grid()

# plt.plot(np.array(solution)[:,0].tolist(),np.array(solution)[:,1].tolist(), marker='*',color='black', linewidth=1, markersize=12, mec='k', mfc='k',label='The Pareto front')


# plt.rc('font',family='Times New Roman') 
# # plt.savefig("allcmp.svg",bbox_inches='tight')
# plt.savefig("1.svg",bbox_inches='tight') 
# plt.show()


# model.gantteplot(model.fitness(result0[0][0])[2],0)

# schedule=[model.fitness(result0[0][j])[2] for j in range(len(solution))]
# for j in range(len(solution)):
#     model.gantteplot(schedule[j],j)