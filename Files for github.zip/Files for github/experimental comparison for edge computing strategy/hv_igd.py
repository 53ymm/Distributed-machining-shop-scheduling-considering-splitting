import sys 
sys.path.append("..") 
sys.path.append("E:/pyfiles/Commoncodes")
sys.path.append("E:/重大相关/个人资料/我的论文/分布式机械加工车间协同分批节能调度/python代码/experimental validation")
from Pareto_min import Pareto_min
import numpy as np
import pandas as pd
from pymoo.indicators.hv import HV
from pymoo.indicators.igd import IGD

import matplotlib.pyplot as plt

import random
random.seed(1)


def Pareto22th(input0):
    return0=[]
    for i in range(len(input0)):
        if input0[i][2]==1.0:
            return0.append([input0[i][0],input0[i][1]])
    return return0
    

def BoxFeature(input_list):
     percentile = np.percentile(input_list, (25, 50, 75), interpolation='linear')
     Q1 = percentile[0]#上四分位数
     Q2 = percentile[1]
     Q3 = percentile[2]#下四分位数
     IQR = Q3 - Q1#四分位距
     ulim = Q3 + 1.5*IQR#上限 非异常范围内的最大值
     llim = Q1 - 1.5*IQR#下限 非异常范围内的最小值
     right_list = []
     Error_Point_num = 0
     value_total = 0
     average_num = 0
     for item in input_list:
         if item < llim or item > ulim:
             Error_Point_num += 1
         else:
             right_list.append(item)
             value_total += item
             average_num += 1
     average_value =  value_total/average_num
     out_list = [average_value,min(right_list), Q1, Q2, Q3, max(right_list)]
     
     return out_list


algorithms=['Edge computing strategy','The traditional strategy']

hv = HV(ref_point=np.array([2600, 23]))
pf=pd.read_excel('Solutions of experimental validation.xlsx')
igd=IGD(np.array(pf))



pop_num=4
repeat_num=20

hv_metric=[[[] for i in range(len(algorithms))] for k in range(pop_num)]
igd_metric=[[[] for i in range(len(algorithms))] for k in range(pop_num)]
datas=[[[[]for m in range(repeat_num)] for i in range(len(algorithms))] for k in range(pop_num)]
datas2=[[[[]for m in range(repeat_num)] for i in range(len(algorithms))] for k in range(pop_num)]

for j in range(pop_num):#30-90
        for i in range(len(algorithms)):
            for m in range(repeat_num):
                    
                if i ==0:
                    datas[j][i][m] = np.array(pd.read_excel('result2\solution'+str(j)+str(m)+'.xlsx',header=None))[1:,1:]
                else:
                    datas[j][i][m] = np.array(pd.read_excel('result2\solution_single'+str(j)+str(m)+'.xlsx',header=None))[1:,1:]
                datas2[j][i][m]=np.array(Pareto_min(datas[j][i][m].tolist()))
                hv_metric[j][i].append(hv(datas2[j][i][m]))
                igd_metric[j][i].append(igd(datas2[j][i][m]))

def assitnumtrans(input0):
    if input0==0:
        return 1
    else:
        return 0


    
  
assit=1

fontsize1=13

c_list = ['green', 'purple']         
for j in range(pop_num):
    plt.figure(assit)
    f=plt.boxplot(igd_metric[j],notch=True,sym='+',patch_artist=True)    				#垂直显示箱线图
    for box, c in zip(f['boxes'], c_list):  # 对箱线图设置颜色
        box.set(color=c, linewidth=2)
        box.set(facecolor=c)
    plt.grid()
    # plt.title(str((assitnumtrans(j)+1)*50)+"-"+str((assitnumtrans(k)+1)*2500))
    plt.xticks(range(len(algorithms)+1),['']+algorithms) ## 可以设置坐标字
    plt.ylabel('IGD', fontsize=fontsize1)#改这个地方可以调 hv igd
    plt.xlabel('The strategies', fontsize=fontsize1)
    plt.rc('font',family='Times New Roman') 
    assit+=1
    plt.tick_params(labelsize = 13)
    plt.savefig(str(assit)+"IGD.svg",bbox_inches='tight')  

c_list = ['blue', 'red']              
for j in range(pop_num):
    plt.figure(assit)
    f=plt.boxplot(hv_metric[j],notch=True,sym='+',patch_artist=True)    				#垂直显示箱线图
    for box, c in zip(f['boxes'], c_list):  # 对箱线图设置颜色
        box.set(color=c, linewidth=2)
        box.set(facecolor=c)
    plt.grid()
    # plt.title(str((assitnumtrans(j)+1)*50)+"-"+str((assitnumtrans(k)+1)*2500))
    plt.xticks(range(len(algorithms)+1),['']+algorithms) ## 可以设置坐标字
    plt.ylabel('HV', fontsize=fontsize1)#改这个地方可以调 hv igd
    plt.xlabel('The strategies', fontsize=fontsize1)
    plt.rc('font',family='Times New Roman') 
    assit+=1
    plt.tick_params(labelsize = 13)
    
    plt.savefig(str(assit)+"HV.svg",bbox_inches='tight') 
                
hv_feature=[[] for i in range(pop_num)]
igd_feature=[[] for i in range(pop_num)]
hv_feature0=[[] for i in range(pop_num)]
igd_feature0=[[] for i in range(pop_num)]

hv_feature0=[]
igd_feature0=[]
for j in range(pop_num):#30-90
        hv_feature[j]= [BoxFeature(hv_metric[j][i]) for i in range(len(algorithms))]
        igd_feature[j]=[BoxFeature(igd_metric[j][i]) for i in range(len(algorithms))]
        hv_feature0=hv_feature0+hv_feature[j]
        igd_feature0=igd_feature0+igd_feature[j]
hv_feature1=np.round(np.array(hv_feature0),1)
igd_feature1=np.round(np.array(igd_feature0),2)
        
        
