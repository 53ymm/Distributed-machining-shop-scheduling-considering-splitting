import threading
import socket
import model
s = socket.socket()
# 绑定端口
s.bind(('127.0.0.1',9006))
# 监听端口
s.listen(5)
Minimum=[0 for i in range(5)]
Minimizer=[0 for i in range(len(Minimum))]
connectednum=[0 for i in range(len(Minimum))]
pop=50
itera=5

def Pareto_min(solutions3):
    optimal_f2=[]
    for i in solutions3:
      if not i in optimal_f2:
        optimal_f2.append(i)
    F2=[]
    for i in range(len(optimal_f2)):
        assis=[j for j in range(len(optimal_f2)) if i!=j]
        assis2=[assis[j] for j in range(len(assis)) if (optimal_f2[i][0]>=optimal_f2[assis[j]][0])&(optimal_f2[i][1]>=optimal_f2[assis[j]][1])]#找出j比i好的个体
        if len(assis2)==0 or optimal_f2[list(set(assis2))[0]]==optimal_f2[i]:#个体i没有被支配    
          F2=F2+[i]
    solutions2=[optimal_f2[F2[j]] for j in range(len(F2))]
    solutions3=sorted(solutions2,key=lambda x:x[0])
    return [solutions3,F2]

class myThread(threading.Thread):  # 继承父类threading.Thread
   def __init__(self, threadID, name, counter):
      threading.Thread.__init__(self)
      self.threadID = threadID
      self.name = name
      self.counter = counter

   def run(self):  # 把要执行的代码写到run函数里面 线程在创建后会直接运行run函数
    # 阻塞等待连接
        sock,addr = s.accept()
        connectednum[self.threadID]=1
        # 一直保持发送和接收数据的状态

        while 1:
            if sum(connectednum)==len(Minimum):
                content=str(pop)+','+str(itera)
                sock.send(content.encode())
                originaltest=((sock.recv(1024000)).decode()).split('$$$$')
                
                for i in range(len(originaltest)):
                    recvtext2=(originaltest[i][2:-2]).split("], [")
                    recvtext21=[recvtext2[j].split(', ') for j in range(len(recvtext2))]
                    recvtext22=[[ float(recvtext21[j][k]) for k in range(len(recvtext21[j])) ] for j in range(len(recvtext21))]
                    if i==0:
                        Minimizer[self.threadID]=recvtext22
                    elif i==1:
                        Minimum[self.threadID]=recvtext22  

                break;        
        sock.close()


threads=[myThread(i, "Thread-"+str(i), i) for i in range(len(Minimum))]

# 开启线程
for i in range(len(threads)):
    threads[i].start()
# 等待线程结束
for i in range(len(threads)):
    threads[i].join()

finalsolution=[]
finalencode=[]
for i in range(len(Minimum)):
    finalsolution.extend(Minimum[i])
    finalencode.extend(Minimizer[i])

finalsolution2=Pareto_min(finalsolution)
finalencode=[finalencode[finalsolution2[1][i]] for i in range(len(finalsolution2[1]))]
finalsolution=finalsolution2[0]