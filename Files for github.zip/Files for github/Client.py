import socket
import sys 
sys.path.append("..") 
sys.path.append("E:/pyfiles/Commoncodes")
# 创建一个socket对象
s1 = socket.socket()
s1.connect(('127.0.0.1', 9006))
# 不断发送和接收数据
import sys 
sys.path.append("..") 
sys.path.append("E:/pyfiles/Commoncodes")
from Pareto_min import Pareto_min
import numpy as np
import model
from pymoo.algorithms.moo.nsga2 import NSGA2
from pymoo.util.ref_dirs import get_reference_directions
from pymoo.core.problem import ElementwiseProblem
from pymoo.optimize import minimize
import pandas as pd
from pymoo.termination import get_termination
import threading
import mobsa
import model as model
n_va=model.n_variables
class MyProblem(ElementwiseProblem):

    def __init__(self):
        super().__init__(n_var=n_va,
                         n_obj=2,
                         n_constr=0,
                         xl=np.array([0.00000001 for i in range(n_va)]),
                         xu=np.array([1 for i in range(n_va)]))

    def _evaluate(self, x, out, *args, **kwargs):
        fitness=model.fitness(x.tolist())
        ec = fitness[0]
        tt = fitness[1]
        out["F"] = [ec, tt]
# 接收数据，最大字节数1024,对返回的二进制数据进行解码
text = ((s1.recv(1024)).decode()).split(',')
print("服务端发送的数据：{}".format(text))
popsize1=int(text[0])
epoch=int(text[1])
CPUtime=epoch
termination = get_termination("time", CPUtime)
algorithm = NSGA2(pop_size=popsize1)
problem = MyProblem()
res = minimize(problem,
              algorithm,
              termination,
              # seed=i,
              verbose=False)

solutions=res.F.tolist()

Encode=res.F.tolist()

Paretoresult=Pareto_min(solutions)

Paretorencode=[Encode[i] for i in Paretoresult[1]]

send_data = str(Paretoresult[0])+"$$$$"+str(Paretorencode)

# socket传递的都是bytes类型的数据,需要转换一下
s1.send(send_data.encode())
print("------------------------------")